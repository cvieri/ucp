<p><div class="clsError">
<b><?php echo _("Warning:"); ?></b>
<br>
<br>
<?php echo _("Cannot connect to Asterisk Manager with "). "<i>" .$mgruser . "</i>"; ?>
<br>
<?php echo _("Asterisk may not be running."); ?>
</div></p>