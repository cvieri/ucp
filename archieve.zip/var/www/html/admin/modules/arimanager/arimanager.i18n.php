<?php 
if (false) {
# name:
_("Asterisk REST Interface Users");
# category:
_("Settings");
# description:
_("Asterisk 12 introduces the Asterisk REST Interface (ARI), a set of RESTful API's for building Asterisk based applications. This module provides the ability to add and remove ARI users.");
# arimanager:
_("Asterisk ARI Users");
}
?>

