
DROP TABLE IF EXISTS vmblast;
DROP TABLE IF EXISTS vmblast_groups;
