<div class='rnav'>
	<ul name='voicemail_menu' id='voicemail_menu' style='max-width:400px;'>
		<?php echo $rnav_list ?>
	</ul>
</div>