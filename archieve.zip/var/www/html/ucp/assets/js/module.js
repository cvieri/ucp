var UCPMC = Class.extend({
	init: function(){

	}
});
