<div class="col-md-2 navigate">
	<?php foreach($views as $view) { ?>

	<?php }?>
</div>
