<div id="module-page-<?php echo $module?>" style="padding-top: 5px;">
	<?php echo $display?>
<div>
