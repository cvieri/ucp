<div id="footer-image">
	<a href="http://www.sangoma.com/">
		<img height="65" src="assets/images/sangoma-logo.png">
	</a>
</div>
<div id="footer-message">
	<?php echo sprintf(_('User Control Panel is released as %s or newer'),'<a href="http://www.gnu.org/licenses/agpl-3.0.html" target="_blank">AGPLV3</a>')?>.<br/>
	<?php echo 'Copyright 2013-'.$year.' Sangoma Technologies Inc'?>.<br/>
	<a href="http://www.sangoma.com/">http://www.sangoma.com/</a><br/>
	<span class="small-text"><?php echo _('The removal of this copyright notice is stricly prohibited')?></span>
</div>
