<div class="col-md-2 navigate">
	<div class="settings-list">
		<div class="settings <?php echo ('history' == $activeList) ? 'active' : ''?>"><a vm-pjax href="?display=dashboard&amp;mod=cdr&amp;sub=<?php echo $ext?>&amp;view=history" class="settings-inner"><?php echo _('View History')?></a></div>
	</div>
	<!--
	<div class="separator-list"></div>
	<div class="settings-list">
		<div class="settings <?php echo ('settings' == $activeList) ? 'active' : ''?>"><a vm-pjax href="?display=dashboard&amp;mod=cdr&amp;sub=<?php echo $ext?>&amp;view=settings" class="settings-inner"><?php echo _('Settings')?> <i class="fa fa-cog"></i></a></div>
	</div>
	-->
</div>
