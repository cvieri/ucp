<div class="col-md-10">
	<h3><?php echo sprintf(_('Conference "%s" Settings'),$settings['description'])?></h3>
	<div class="conferencesettings">
		<div id="message" class="alert" style="display:none;"></div>
		<form role="form">
		</form>
	</div>
</div>
