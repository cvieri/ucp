<div class="col-md-10">
	<div class="group-container">
		<form role="form">
			<div class="form-group">
				<label for="name"><?php echo _('Group Name')?></label><br/>
				<input id="name" class="form-control" type="text" placeholder="Group Name">
			</div>
			<button id="addgroup" class="btn btn-default"><?php echo _('Add Group')?></button>
		</form>
	</div>
</div>
